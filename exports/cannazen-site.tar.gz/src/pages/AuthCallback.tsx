import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import LoadingSpinner from '../components/ui/LoadingSpinner';

export default function AuthCallback() {
  const navigate = useNavigate();
  const processed = useRef(false);

  useEffect(() => {
    if (processed.current) return;
    processed.current = true;

    if (!isSupabaseConfigured || !supabase) {
      navigate('/', { replace: true });
      return;
    }

    const handleCallback = async () => {
      const params = new URLSearchParams(window.location.search);
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const code = params.get('code');
      const accessToken = hashParams.get('access_token');

      try {
        if (code) {
          await supabase.auth.exchangeCodeForSession(code);
        } else if (accessToken) {
          const refreshToken = hashParams.get('refresh_token') || '';
          await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken,
          });
        } else {
          const { data } = await supabase.auth.getSession();
          if (!data.session) {
            navigate('/connexion', { replace: true });
            return;
          }
        }

        navigate('/compte', { replace: true });
      } catch (err) {
        console.error('Auth callback error:', err);
        navigate('/connexion', { replace: true });
      }
    };

    handleCallback();
  }, [navigate]);

  return <LoadingSpinner />;
}
